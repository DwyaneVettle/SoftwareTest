/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=111", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("Hm_lvt_ccd369c076594bbc189bd23d92216a6a=1668152073; DOMAIN=weather-api.extfans.com");

	web_add_cookie("__gpi=UID=00000880f2fcf7a8:T=1660269229:RT=1668152076:S=ALNI_MbhE-MmxRv-NeakKN4-szfDECGKJQ; DOMAIN=weather-api.extfans.com");

	web_add_cookie("_ga=GA1.1.700386730.1614862307; DOMAIN=weather-api.extfans.com");

	web_add_cookie("_ga_56ND7K31H4=GS1.1.1668152073.6.1.1668152239.0.0.0; DOMAIN=weather-api.extfans.com");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("sec-ch-ua", 
		"\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(4);

	web_url("forecast", 
		"URL=https://weather-api.extfans.com/weather/forecast?lang=zh-CN&cid=CN101270101", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("X-Goog-Update-AppId", 
		"aicmkgpgakddgnaphhhpliifpcfhicfo,bkhaagjahfmjljalopjnoealnfndnagc,bpojelgakakmcfmjfilgdlmhefphglae,chphlpgkkbolifaimnlloiipkdnihall,cieikaeocafmceoapfogpffaalkncpkc,dhdgffkkebhmkfjojejmpbldmpobfkfo,hiidjliailpkjeigakikbfedlfijngih,hmlpiahhoampfgiodhahfofmeppmkaeo,iahnhfdhidomcpggpaimmmahffihkfnj,jcbmcnpepaddcedmjdcmhbekjhbfnlff,laookkfknpbbblfpciffpaejjkokdgca,ncldcbhpeplkfijdhnoepdgdnmjkckij,nhdogjmejiglipccpnnnanhbledajbpd,nmmhkkegccagdldgiimedpiccmgmieda,nnnkddnnlpamobajfibfdgfnbcnkgngh,"
		"ogdlpmhglpejoiomcodnpjnfgcpmgale");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chromecrx-111.0.5563.111");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=12:KauDshGFqkJC1A3qriz-2Jl1nW2qXlTEhEgVJUhkbgg&cup2hreq=96edd3219be6511d5a4dfbfea7665c01dcbf01997a20b81440052965c7c956cf", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"aicmkgpgakddgnaphhhpliifpcfhicfo\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"2.1.1.2\"}]},\"ping\":{\"ping_freshness\":\"{6a119fd1-c2de-4328-8e4e-864a50c24952}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"1.1.2\"},{\"appid\":\"bkhaagjahfmjljalopjnoealnfndnagc\",\"cohort\":\"1::\",\"enabled\":true,\""
		"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.e4d10617e6c95cb829259f0e58cc619586411b09a20ef0c013f65d450d3a7599\"}]},\"ping\":{\"ping_freshness\":\"{931a44eb-df63-4af4-93b6-f7abf9660299}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"7.8.3\"},{\"appid\":\"bpojelgakakmcfmjfilgdlmhefphglae\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"2.0.51\"}]},\"ping\":{\"ping_freshness\":\""
		"{98a70cbf-e247-4abd-b86f-bff2c161d3ea}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"0.51\"},{\"appid\":\"chphlpgkkbolifaimnlloiipkdnihall\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"2.1.58\"}]},\"ping\":{\"ping_freshness\":\"{a2ea7ff0-9668-4715-ab21-f7e58c6aa086}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"1.58\"},{\"appid\":\"cieikaeocafmceoapfogpffaalkncpkc\",\"cohort\":\"1::\",\"disabled\":[{\"reason\":1}],\""
		"enabled\":false,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.6c50e7790c4da201f06424c7db68dcd6bfeb65f1a611bf4887706d3c8005febb\"}]},\"ping\":{\"ping_freshness\":\"{f98a0a30-6083-4be5-8b9d-2d90d52fb232}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"2.8.2\"},{\"appid\":\"dhdgffkkebhmkfjojejmpbldmpobfkfo\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\""
		"1.3569a2d692562e822e27de310e2aad8706f7e5e38e0304d6c40bfa7c76df3b59\"}]},\"ping\":{\"ping_freshness\":\"{7f215f39-7402-4db8-bdea-a6f63a2e1f70}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"4.18.1\"},{\"appid\":\"hiidjliailpkjeigakikbfedlfijngih\",\"cohort\":\"1::\",\"disabled\":[{\"reason\":1}],\"enabled\":false,\"installdate\":5752,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"2.1.3.0\"}]},\"ping\":{\"ping_freshness\":\"{cd8ccf9a-c7a8-4589-a88f-39435d6d177f"
		"}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"1.3.0\"},{\"appid\":\"hmlpiahhoampfgiodhahfofmeppmkaeo\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.27d8fa57b33dfc2f6431ba005fb0e89515a999f4206e3084e3e6dfe1974a9d8e\"}]},\"ping\":{\"ping_freshness\":\"{5bd67637-23a5-4d81-8b7c-e7eb561c7a2d}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"3.0.3\"},{\"appid\":\"iahnhfdhidomcpggpaimmmahffihkfnj\",\"cohort\":\"1::\",\""
		"enabled\":true,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"2.0.6.2\"}]},\"ping\":{\"ping_freshness\":\"{92f4921f-fc02-48ee-a9e4-e9c56a37f54e}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"0.6.2\"},{\"appid\":\"jcbmcnpepaddcedmjdcmhbekjhbfnlff\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.f2e2d10fc40889c69c8255dd4f05b99de898c6d77259cba8d45710c47861dbf8\"}]},\"ping\":{\""
		"ping_freshness\":\"{68935ebe-d1ce-44c9-be40-269598c7ef27}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"0.1.2\"},{\"appid\":\"laookkfknpbbblfpciffpaejjkokdgca\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.421a0cc315da157cc1dbcf4681634a76bbc69794c679f331e4a87515f71a5df9\"}]},\"ping\":{\"ping_freshness\":\"{5d81975f-b879-485e-acd6-e0e5b7c8dcc9}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"2.7.61\"},{\"appid\":\""
		"ncldcbhpeplkfijdhnoepdgdnmjkckij\",\"cohort\":\"1::\",\"disabled\":[{\"reason\":1}],\"enabled\":false,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.6a0bc1a14af772a6b486ba139ae67cbf8aebb6c7504ca6ca856123f5fe6cad76\"}]},\"ping\":{\"ping_freshness\":\"{21782432-8367-425a-8a7e-a34faac29cdc}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"2.2.2\"},{\"appid\":\"nhdogjmejiglipccpnnnanhbledajbpd\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5834,\""
		"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.d47a47fb74d8e7a78f7369fdb91b40eb5f887db29d9a25c61c0a45897606179b\"}]},\"ping\":{\"ping_freshness\":\"{8ef61cee-a695-4fcb-aa4f-d6ab786703e3}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"6.5.0\"},{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"other\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\""
		"1.81e3a4d43a73699e1b7781723f56b8717175c536685c5450122b30789464ad82\"}]},\"ping\":{\"ping_freshness\":\"{2a7d79ee-f947-4194-b540-fcc23b6e000e}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"1.0.0.6\"},{\"appid\":\"nnnkddnnlpamobajfibfdgfnbcnkgngh\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.d97c4f2bd824a231fdd0326e4054ddd900c0aafbf3a67cbfb7c86491ee456d0a\"}]},\"ping\":{\"ping_freshness\":\""
		"{f8c63b01-fe52-45ff-b325-69c9bc11cbc7}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"10.0.103\"},{\"appid\":\"ogdlpmhglpejoiomcodnpjnfgcpmgale\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"lang\":\"zh-CN\",\"packages\":{\"package\":[{\"fp\":\"1.cddc4613767e08f8c5a66aea92aab48abfd6bb32797ce32cbb091dcfda9bbf58\"}]},\"ping\":{\"ping_freshness\":\"{26ee99b7-f642-41bb-86fd-51ae9b606d1e}\",\"rd\":5936},\"updatecheck\":{},\"version\":\"3.2.9\"}],\"arch\":\"x64\",\"dedup\":\"cr\","
		"\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":10,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19044.2728\"},\"prodversion\":\"111.0.5563.111\",\"protocol\":\"3.1\",\"requestid\":\"{afbb6120-e081-49ba-bee6-01f4b4a12f58}\",\"sessionid\":\"{a27f190b-0f4b-4695-9e50-33cdefe52d7b}\",\"updaterversion\":\"111.0.5563.111\"}}", 
		LAST);

	return 0;
}
